<?php
/*
Plugin Name: QVisualization Plugin per a Wordpress
Plugin URI: http://plugin.issim.net/QVisual2
Description: Visualització del contingut d'un blog mitjançant p5js.
Version: 0.1
Author: Quelic Berga Carreras, Carlos Casado
Author URI: http://www.caotic.net
License: GPL2
*/

function posts_category() {
	global $wpdb;

	$query = "
		SELECT $wpdb->posts.post_date_gmt, $wpdb->posts.post_title, UNIX_TIMESTAMP($wpdb->posts.post_date_gmt), $wpdb->posts.comment_count, $wpdb->posts.post_content, $wpdb->terms.name FROM $wpdb->posts
		LEFT JOIN $wpdb->term_relationships ON ($wpdb->posts.ID = $wpdb->term_relationships.object_id)
		LEFT JOIN $wpdb->term_taxonomy ON ($wpdb->term_relationships.term_taxonomy_id = $wpdb->term_taxonomy.term_taxonomy_id)
		LEFT JOIN $wpdb->terms ON ($wpdb->term_taxonomy.term_id = $wpdb->terms.term_id)
		WHERE $wpdb->term_taxonomy.taxonomy = 'category'
		AND $wpdb->posts.post_status = 'publish'
		ORDER BY $wpdb->posts.post_date_gmt;
	";
	return $wpdb->get_results($query,ARRAY_N);
}

function categorias() {
global $wpdb;
	$query = "SELECT $wpdb->terms.name FROM $wpdb->terms
		LEFT JOIN $wpdb->term_taxonomy ON ($wpdb->term_taxonomy.term_id = $wpdb->terms.term_id)
		WHERE $wpdb->term_taxonomy.taxonomy = 'category'
	";

	return $wpdb->get_results($query,ARRAY_N);
}

function escribe_array(){


echo'	<script src="libraries/p5.js" type="text/javascript"></script>';
echo'	<script src="libraries/p5.dom.js" type="text/javascript"></script>';
echo'	<script src="libraries/p5.sound.js" type="text/javascript"></script>';
echo'	<script src="visualization.js" type="text/javascript"></script>';
echo'

/******************************
 *  Visualització de la info d
 * un wordpress.
 *
 *
 *
 ******************************/


 //DATOS:

 ';

	$myPrueba = posts_category();
	$total=count($myPrueba);
	$ii=0;
	echo "String[][] datos = {";
	for ($i=0; $i<$total; $i++) {
		echo "\n{";
		for ($j=0; $j<6;$j++) {
			if ($j == 5) {
				if (($i<$total-1) && ($myPrueba[$i][0] == $myPrueba[$i+1][0])) {
					while (($i<$total-1) && ($myPrueba[$i][0] == $myPrueba[$i+1][0])) {
						echo '"'.$myPrueba[$i++][$j].'",';
					}
					echo '"'.$myPrueba[$i++][$j].'"';
				} else 	echo '"'.$myPrueba[$i][$j].'"';
			} else {
				if ($j == 4) {
					echo '"'.strlen($myPrueba[$i][$j]).'",';

				} else {
					echo '"'.$myPrueba[$i][$j].'",';
				}
			}
		}
		echo "}";
		$ii++;
		if ($i < ($total-1)) echo ",";
	}
	echo "};\n";
	echo "int nPosts = ".$ii."; \n";

	escribe_categorias();

}


function escribe_categorias(){
	$aCat=categorias();
	$total=count($aCat);
	echo "String[] categorias = {";
	for ($i=0;$i<$total;$i++) {
		echo '"'.$aCat[$i][0].'"';
		if ($i<$total-1) echo ",";
	}
	echo "};\n int nCategorias = $total;";
}
add_action ( 'get_footer' , 'escribe_array' );

?>
